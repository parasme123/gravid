//APP Constants should be kept here

// export const base_url = 'https://reqres.in/api/'
export const base_url = 'https://rasatva.apponedemo.top/gravid/api/'


export const imageurl = "https://rasatva.apponedemo.top/gravid/"
