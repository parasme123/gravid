export default Fonts = {
  OptimaBlack: "OptimaLTPro-Black",
  OptimaBlackItalic: "OptimaLTPro-BlackItalic",
  OptimaBold: "OptimaLTPro-Bold",
  OptimaBoldItalic: "OptimaLTPro-BoldItalic",
  OptimaDemiBold: "OptimaLTPro-DemiBold",
  OptimaDemiBoldItalic: "OptimaLTPro-DemiBoldItalic",
  OptimaExtraBlack: "OptimaLTPro-ExtraBlack",
  OptimaExtraBlackIta: "OptimaLTPro-ExtraBlackIta",
  OptimaItalic: "OptimaLTPro-Italic",
  OptimaMedium: "OptimaLTPro-Medium",
  OptimaMediumItalic: "OptimaLTPro-MediumItalic",
  OptimaRegular: "OptimaLTPro-Roman",
  OptimaRegular: "Optima Regular"
}