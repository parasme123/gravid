import * as _Svg from "./svgs";
export const svgs = _Svg;

import _Fonts from "./fonts";
export const fonts = _Fonts;

import _colors from "./colors";
export const colors = _colors;